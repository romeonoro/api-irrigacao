<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PivotController;
use App\Http\Controllers\IrrigationController;

Route::post('/auth/register', [AuthController::class, 'register']);
Route::post('/auth/login', [AuthController::class, 'login']);

Route::middleware('auth:api')->group(function () {
    Route::get('/pivots', [PivotController::class, 'index']);
    Route::post('/pivots', [PivotController::class, 'store']);
    Route::get('/pivots/{id}', [PivotController::class, 'show']);
    Route::put('/pivots/{id}', [PivotController::class, 'update']);
    Route::delete('/pivots/{id}', [PivotController::class, 'destroy']);

    Route::get('/irrigations', [IrrigationController::class, 'index']);
    Route::post('/irrigations', [IrrigationController::class, 'store']);
    Route::get('/irrigations/{id}', [IrrigationController::class, 'show']);
    Route::delete('/irrigations/{id}', [IrrigationController::class, 'destroy']);
});
