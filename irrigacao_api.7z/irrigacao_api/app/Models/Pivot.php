<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Pivot extends Model
{
    use HasFactory;

    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'description',
        'flowRate',
        'minApplicationDepth',
        'user_id',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($pivot) {
            $pivot->id = (string) Str::uuid();
        });
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function irrigations()
    {
        return $this->hasMany(Irrigation::class);
    }
}
