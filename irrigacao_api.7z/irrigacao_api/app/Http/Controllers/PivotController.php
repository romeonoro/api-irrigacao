<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pivot;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class PivotController extends Controller
{
    public function index()
    {
        return response()->json(Auth::user()->pivots);
    }

    public function show($id)
    {
        $pivot = Pivot::where('user_id', Auth::id())->findOrFail($id);
        return response()->json($pivot);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'description' => 'required|string',
            'flowRate' => 'required|numeric',
            'minApplicationDepth' => 'required|numeric',
        ]);

        $pivot = Pivot::create([
            'id' => Str::uuid(),
            'description' => $validated['description'],
            'flowRate' => $validated['flowRate'],
            'minApplicationDepth' => $validated['minApplicationDepth'],
            'user_id' => Auth::id()
        ]);

        return response()->json([
            'message' => 'Pivot created successfully!',
            'pivot' => $pivot
        ], 201);
    }

    public function update(Request $request, $id)
    {
        $pivot = Pivot::where('user_id', Auth::id())->findOrFail($id);
        $pivot->update($request->only(['description', 'flowRate', 'minApplicationDepth']));

        return response()->json(['message' => 'Pivot updated successfully!', 'pivot' => $pivot]);
    }

    public function destroy($id)
    {
        $pivot = Pivot::where('user_id', Auth::id())->findOrFail($id);
        $pivot->delete();

        return response()->json(['message' => 'Pivot deleted successfully']);
    }
}
