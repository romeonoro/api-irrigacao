<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Irrigation;
use App\Models\Pivot;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class IrrigationController extends Controller
{
    public function index()
    {
        return response()->json(Auth::user()->irrigations);
    }

    public function show($id)
    {
        $irrigation = Irrigation::where('user_id', Auth::id())->findOrFail($id);
        return response()->json($irrigation);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'pivotId' => 'required|uuid',
            'applicationAmount' => 'required|numeric',
            'irrigationDate' => 'required|date',
        ]);

        $pivot = Pivot::where('user_id', Auth::id())->find($validated['pivotId']);

        if (!$pivot) {
            return response()->json(['error' => 'Pivot not found or unauthorized'], 400);
        }

        $irrigation = Irrigation::create([
            'id' => Str::uuid(),
            'pivot_id' => $validated['pivotId'],
            'application_amount' => $validated['applicationAmount'],
            'irrigation_date' => $validated['irrigationDate'],
            'user_id' => Auth::id()
        ]);

        return response()->json([
            'message' => 'Irrigation registered successfully!',
            'irrigation' => $irrigation
        ], 201);
    }

    public function destroy($id)
    {
        $irrigation = Irrigation::where('user_id', Auth::id())->findOrFail($id);
        $irrigation->delete();

        return response()->json(['message' => 'Irrigation record deleted successfully']);
    }
}
